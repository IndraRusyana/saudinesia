<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TransportRoutes extends Model
{
    //
    protected $fillable = ['transport_id', 'routes'];

    public function transport()
    {
        return $this->belongsTo(Transport::class);
    }
}
