<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LandArrangement extends Model
{
    use HasFactory;

    protected $fillable = ['umroh_package_id', 'serviceable_type', 'serviceable_id', 'custom_name', 'keterangan'];

    public function umrohPackage()
    {
        return $this->belongsTo(Umroh::class);
    }

    public function serviceable()
    {
        return $this->morphTo();
    }
}
