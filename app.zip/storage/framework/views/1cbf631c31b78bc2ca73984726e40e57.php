

<?php $__env->startSection('title'); ?>
    Dashboard LA | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('LA'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div id="body">
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="content">
                <div class="container">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <h2><?php echo e(isset($la) ? 'Edit' : 'Tambah'); ?> Land Arrangement</h2>

                    <form
                        action="<?php echo e(isset($la) ? route('land-arrangements.update', $la->id) : route('land-arrangements.store')); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($la)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>

                        
                        <div class="mb-3">
                            <label for="name">Nama Land Arrangement</label>
                            <input type="text" name="name" id="name" class="form-control"
                                value="<?php echo e(old('name', $la->name ?? '')); ?>" required>
                        </div>

                        
                        <label>Layanan</label>
                        <div id="items-wrapper">
                            <?php
                                $items = old(
                                    'items',
                                    isset($la)
                                        ? $la->items->toArray()
                                        : [
                                            [
                                                'serviceable_type' => '',
                                                'serviceable_id' => '',
                                                'custom_name' => '',
                                                'keterangan' => '',
                                            ],
                                        ],
                                );
                            ?>

                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isCustom = empty($item['serviceable_type']);
                                ?>
                                <div class="item-group border p-3 mb-3 position-relative">
                                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 m-2"
                                        onclick="this.parentElement.remove()">Hapus</button>

                                    
                                    <div class="mb-2">
                                        <label>Pilih Jenis Layanan:</label><br>
                                        <label>
                                            <input type="radio" name="items[<?php echo e($index); ?>][source]"
                                                value="database" <?php echo e(!$isCustom ? 'checked' : ''); ?>

                                                onchange="toggleItemType(this)"> Layanan dari Database
                                            </label>

                                        <label class="ms-3">
                                            <input type="radio" name="items[<?php echo e($index); ?>][source]" 
                                                value="custom" <?php echo e($isCustom ? 'checked' : ''); ?> 
                                                onchange="toggleItemType(this)"> Layanan Kustom
                                        </label>
                                    </div>

                                    
                                    <div class="item-database" style="<?php echo e($isCustom ? 'display:none' : ''); ?>">
                                        <div class="mb-2">
                                            <label>Tipe Layanan</label>
                                            <select name="items[<?php echo e($index); ?>][serviceable_type]"
                                                class="form-control serviceable-type" onchange="fetchServiceables(this)">
                                                <option value="">-- Pilih --</option>
                                                <option value="App\Models\Hotel"
                                                    <?php echo e($item['serviceable_type'] == 'App\Models\Hotel' ? 'selected' : ''); ?>>
                                                    Hotel</option>
                                                <option value="App\Models\Transport"
                                                    <?php echo e($item['serviceable_type'] == 'App\Models\Transport' ? 'selected' : ''); ?>>
                                                    Transport</option>
                                            </select>
                                        </div>

                                        <div class="mb-2">
                                            <label>Layanan</label>
                                            <select name="items[<?php echo e($index); ?>][serviceable_id]"
                                                class="form-control serviceable-select">
                                                <?php if(!$isCustom): ?>
                                                    <?php
                                                        $modelClass = $item['serviceable_type'];
                                                        $options = class_exists($modelClass)
                                                            ? app($modelClass)::all()
                                                            : [];
                                                    ?>
                                                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($opt->id); ?>"
                                                            <?php echo e($opt->id == ($item['serviceable_id'] ?? null) ? 'selected' : ''); ?>>
                                                            <?php echo e($opt->name ?? 'Unnamed'); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>

                                    
                                    <div class="item-custom" style="<?php echo e(!$isCustom ? 'display:none' : ''); ?>">
                                        <div class="mb-2">
                                            <label>Nama Layanan (Kustom)</label>
                                            <input type="text" name="items[<?php echo e($index); ?>][custom_name]"
                                                class="form-control" value="<?php echo e($item['custom_name'] ?? ''); ?>">
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="mb-2">
                                        <label>Keterangan</label>
                                        <textarea name="items[<?php echo e($index); ?>][keterangan]" class="form-control"><?php echo e($item['keterangan'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                        <div class="row">
                            <div class="col-sm-3 mb-3">
                                <button type="button" class="btn btn-sm btn-success" onclick="addItem()">+ Tambah
                                    Layanan</button>
                            </div>
                        </div>

                        <button class="btn btn-primary" type="submit">Simpan</button>
                        <a href="<?php echo e(route('land-arrangements.index')); ?>" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
<script>
    function toggleItemType(radio) {
        const wrapper = radio.closest('.item-group');
        const isCustom = radio.value === 'custom';

        wrapper.querySelector('.item-database').style.display = isCustom ? 'none' : '';
        wrapper.querySelector('.item-custom').style.display = isCustom ? '' : 'none';
    }

    function addItem() {
        const wrapper = document.getElementById('items-wrapper');
        const count = wrapper.children.length;
        const html = `
            <div class="item-group border p-3 mb-3 position-relative">
                <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 m-2" onclick="this.parentElement.remove()">Hapus</button>

                <div class="mb-2">
                    <label>Pilih Jenis Layanan:</label><br>
                    <label><input type="radio" name="items[${count}][source]" value="database" checked onchange="toggleItemType(this)"> Layanan dari Database</label>
                    <label class="ms-3"><input type="radio" name="items[${count}][source]" value="custom" onchange="toggleItemType(this)"> Layanan Kustom</label>
                </div>

                <div class="item-database">
                    <div class="mb-2">
                        <label>Tipe Layanan</label>
                        <select name="items[${count}][serviceable_type]" class="form-control serviceable-type" onchange="fetchServiceables(this)">
                            <option value="">-- Pilih --</option>
                            <option value="App\\\\Models\\\\Hotel">Hotel</option>
                            <option value="App\\\\Models\\\\Transport">Transport</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label>Layanan</label>
                        <select name="items[${count}][serviceable_id]" class="form-control serviceable-select"></select>
                    </div>
                </div>

                <div class="item-custom" style="display: none;">
                    <div class="mb-2">
                        <label>Nama Layanan (Kustom)</label>
                        <input type="text" name="items[${count}][custom_name]" class="form-control">
                    </div>
                </div>

                <div class="mb-2">
                    <label>Keterangan</label>
                    <textarea name="items[${count}][keterangan]" class="form-control"></textarea>
                </div>
            </div>
        `;
        wrapper.insertAdjacentHTML('beforeend', html);
    }

    function fetchServiceables(select) {
        const type = select.value;
        const parent = select.closest('.item-group');
        const serviceableSelect = parent.querySelector('.serviceable-select');

        fetch(`/api/serviceables?type=${encodeURIComponent(type)}`)
            .then(res => res.json())
            .then(data => {
                serviceableSelect.innerHTML = '';
                data.forEach(item => {
                    const opt = document.createElement('option');
                    opt.value = item.id;
                    opt.textContent = item.name || 'Unnamed';
                    serviceableSelect.appendChild(opt);
                });
            })
            .catch(error => {
                console.error("Fetch error:", error);
            });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/LA/form.blade.php ENDPATH**/ ?>