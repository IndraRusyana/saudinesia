

<?php $__env->startSection('title'); ?>
    Pesanan saya | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pesanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h3 class="mb-4">Transaksi Saya</h3>

        <?php
            $grouped = $transactions->groupBy('status');
            $statuses = [
                'belum_bayar' => 'belum bayar',
                'sudah_bayar' => 'sudah bayar',
                'sudah_diverifikasi' => 'sudah diverifikasi',
                'batal' => 'batal',
            ];

        ?>

        <ul class="nav nav-tabs mb-3" id="transactionTabs" role="tablist">
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php if($loop->first): ?> active <?php endif; ?>" id="<?php echo e($key); ?>-tab"
                        data-bs-toggle="tab" data-bs-target="#<?php echo e($key); ?>" type="button" role="tab"
                        aria-controls="<?php echo e($key); ?>" aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">
                        <?php echo e($label); ?>

                    </button>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <!-- Tab Contents -->
        <div class="tab-content" id="transactionTabsContent">
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>" id="<?php echo e($key); ?>"
                    role="tabpanel" aria-labelledby="<?php echo e($key); ?>-tab">
                    <?php
                        $statusLookup = str_replace('_', ' ', $key);
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $grouped[$statusLookup] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card mb-3">
                            <div class="card-header d-flex justify-content-between">
                                <div>
                                    <strong>Invoice:</strong> <?php echo e($transaction->invoice_number); ?><br>
                                    <strong>Status:</strong> <?php echo e(ucfirst($transaction->status)); ?>

                                </div>
                                <div class="text-end">
                                    <strong>Total:</strong> Rp
                                    <?php echo e(number_format($transaction->total_amount, 0, ',', '.')); ?><br>
                                    <small class="text-muted"><?php echo e($transaction->created_at->format('d M Y H:i')); ?></small>
                                </div>
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $transaction->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <strong><?php echo e(class_basename($item->itemable_type)); ?></strong> -
                                            <?php echo e($item->description); ?><br>
                                            Qty: <?php echo e($item->quantity); ?> × Rp
                                            <?php echo e(number_format($item->unit_price, 0, ',', '.')); ?> =
                                            <strong>Rp <?php echo e(number_format($item->total_price, 0, ',', '.')); ?></strong>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($transaction->status === 'belum bayar'): ?>
                                        <div class="mt-3 text-end">
                                            <a href="<?php echo e(route('invoice.show', $transaction->id)); ?>"
                                                class="btn btn-success">
                                                Upload Bukti Pembayaran
                                            </a>
                                        </div>
                                    <?php endif; ?>


                                </ul>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-secondary">Tidak ada transaksi dengan status
                            <strong><?php echo e(ucfirst($label)); ?></strong>.
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/transactions/index.blade.php ENDPATH**/ ?>