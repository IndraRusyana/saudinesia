

<?php $__env->startSection('title'); ?>
    Dashboard Periode | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('periode'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="row px-2">
                        <h4>Verifikasi Transaksi</h4>

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Invoice</th>
                                    <th>User</th>
                                    <th>email</th>
                                    <th>Status</th>
                                    <th>Bukti</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($t->invoice_number); ?></td>
                                        <td><?php echo e($t->user->profile->nama_lengkap); ?></td>
                                        <td><?php echo e($t->user->email); ?></td>
                                        
                                        <td>
                                            <?php
                                                $statusLabels = [
                                                    'belum bayar' => 'warning',
                                                    'sudah bayar' => 'info',
                                                    'sudah diverifikasi' => 'success',
                                                    'batal' => 'danger',
                                                ];
                                            ?>
                                            <span class="badge bg-<?php echo e($statusLabels[$t->status] ?? 'secondary'); ?>">
                                                <?php echo e(ucfirst($t->status)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($t->payment_proof): ?>
                                                <a class="btn btn-outline-light" href="<?php echo e(asset('uploads/' . $t->payment_proof)); ?>"
                                                    target="_blank">Lihat</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($t->status === 'belum bayar'): ?>
                                                <span class="text-muted">Menunggu pembayaran</span>
                                            <?php elseif($t->status === 'sudah bayar'): ?>
                                                <form action="<?php echo e(route('admin.transactions.verify', $t->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-success btn-sm">Verifikasi</button>
                                                </form>
                                            <?php elseif($t->status === 'sudah diverifikasi'): ?>
                                                <span class="text-muted">Selesai</span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php if($transactions->hasPages()): ?>
                            <div class="my-4 d-flex justify-content-center">
                                <?php echo $transactions->withQueryString()->links('pagination::bootstrap-5'); ?>

                            </div>
                        <?php endif; ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/transactions/index.blade.php ENDPATH**/ ?>