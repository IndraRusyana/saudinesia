

<?php $__env->startSection('title'); ?>
    Dashboard Transport | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Transport'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <div class="page-title my-3">
                        <h3 class="mb-0">Edit Transport</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">Form Edit Transport</div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title mb-3">Silahkan isi form berikut untuk mengubah Transport</h5>
                                    <form action="<?php echo e(route('admin.transport.update', $transport->id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>

                                        <div class="mb-3 row">
                                            <label class="col-sm-2 col-form-label">Nama Transport</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="name" class="form-control"
                                                    value="<?php echo e(old('name', $transport->name)); ?>">
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label class="col-sm-2 col-form-label">Deskripsi</label>
                                            <div class="col-sm-10">
                                                <textarea name="description" class="form-control"><?php echo e(old('description', $transport->description)); ?></textarea>
                                            </div>
                                        </div>

                                         <div class="mb-3 row">
                                            <label class="col-sm-2 col-form-label">Tipe Transport</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="type" class="form-control"
                                                    value="<?php echo e(old('name', $transport->type)); ?>">
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label for="route" class="col-sm-2 form-label">Rute</label>
                                            <div class="col-sm-10">
                                                <select name="route" id="route" class="form-select" required>
                                                    <option value="">-- Pilih Rute --</option>
                                                    <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"
                                                            <?php echo e($transport->route_id == $item->id ? 'selected' : ''); ?>>
                                                            <?php echo e($item->routes); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="mb-3 pt-2 row">
                                            <label>Gambar Transport (maksimal 4)</label>
                                            <div class="row">
                                                <?php $__currentLoopData = range(1, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $image = $transport->images->get($i - 1);
                                                    ?>
                                                    <div class="col-md-3 mb-3">
                                                        <label for="image<?php echo e($i); ?>">Gambar
                                                            <?php echo e($i); ?></label>
                                                        <input type="file" name="image<?php echo e($i); ?>"
                                                            class="form-control mb-1">
                                                        <?php if($image): ?>
                                                            <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>"
                                                                class="img-thumbnail" width="150">
                                                        <?php else: ?>
                                                            <img src="https://via.placeholder.com/150x100?text=No+Image"
                                                                class="img-thumbnail" width="150">
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>

                                        <h5>Harga per Periode</h5>
                                        <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $existingPrice = $transport->prices
                                                    ->where('period_id', $period->id)
                                                    ->first();
                                            ?>
                                            <div class="border p-3 mb-3 rounded">
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="checkbox"
                                                        value="<?php echo e($period->id); ?>" name="active_periods[]"
                                                        id="period_<?php echo e($period->id); ?>"
                                                        <?php echo e($existingPrice ? 'checked' : ''); ?>>
                                                    <label class="form-check-label" for="period_<?php echo e($period->id); ?>">
                                                        <strong><?php echo e($period->name); ?></strong>
                                                        (<?php echo e($period->formatted_start_date); ?> -
                                                        <?php echo e($period->formatted_end_date); ?>)
                                                    </label>
                                                </div>

                                                <div class="mt-2">
                                                    <label>Harga</label>
                                                    <input type="number" name="prices[<?php echo e($period->id); ?>]"
                                                        class="form-control"
                                                        value="<?php echo e($existingPrice ? $existingPrice->price : ''); ?>">
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <button type="submit" class="btn btn-success">Update Transport</button>
                                        <a href="<?php echo e(route('admin.transport.index')); ?>" class="btn btn-secondary">Batal</a>
                                    </form>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/transport/edit.blade.php ENDPATH**/ ?>