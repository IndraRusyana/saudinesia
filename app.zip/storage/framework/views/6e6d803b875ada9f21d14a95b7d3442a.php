

<?php $__env->startSection('title'); ?>
    Checkout | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <section>
            <div class="container contact-form-section py-5 ">
                <div class="form-section shadow-sm border">
                    <!-- Stepper -->
                    <div class="stepper mb-4">
                        <div class="step-circle">1</div>
                        <div class="step-circle inactive">2</div>
                        <div class="step-circle inactive">3</div>
                    </div>

                    <h5 class="fw-bold">Contact details</h5>
                    <p class="text-muted">Please fill your information for reservation info</p>

                    <!-- Name & Email -->
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Name</label>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="John Carter">
                                <span class="input-group-text"><i class="bi bi-person"></i></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <div class="input-group">
                                <input type="email" class="form-control" placeholder="Email address">
                                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                            </div>
                        </div>
                    </div>

                    <!-- Phone Number -->
                    <div class="mt-3">
                        <label class="form-label">Phone Number</label>
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="(123) 456 - 7890">
                            <span class="input-group-text"><i class="bi bi-phone"></i></span>
                        </div>
                    </div>

                    <!-- Button -->
                    <div class="text-end mt-4">
                        <button class="btn btn-dark btn-rounded">Next step</button>
                    </div>
                </div>

            </div>

        </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/checkout1.blade.php ENDPATH**/ ?>