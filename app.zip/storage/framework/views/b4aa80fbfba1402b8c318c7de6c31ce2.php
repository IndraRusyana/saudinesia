

<?php $__env->startSection('title'); ?>
    Checkout | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <section>
            <div class="container contact-form-section py-5">
                <div class="form-section shadow-sm border">
                    <h3>Konfirmasi Checkout</h3>

                    <form action="<?php echo e(route('checkout.multiple')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Deskripsi</th>
                                    <th>Kuantitas</th>
                                    <th>Harga Satuan</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $grandTotal = 0; ?>
                                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $grandTotal += $cart->quantity * $cart->unit_price; ?>
                                    <tr>
                                        <td><?php echo e(class_basename($cart->itemable_type)); ?> #<?php echo e($cart->itemable_id); ?></td>
                                        <td><?php echo e($cart->description); ?></td>
                                        <td><?php echo e($cart->quantity); ?></td>
                                        <td>Rp <?php echo e(number_format($cart->unit_price, 0, ',', '.')); ?></td>
                                        <td>Rp <?php echo e(number_format($cart->quantity * $cart->unit_price, 0, ',', '.')); ?></td>
                                    </tr>
                                    <input type="hidden" name="cart_ids[]" value="<?php echo e($cart->id); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="4" class="text-end">Total</th>
                                    <th>Rp <?php echo e(number_format($grandTotal, 0, ',', '.')); ?></th>
                                </tr>
                            </tfoot>
                        </table>

                        <button type="submit" class="btn btn-primary">Buat Invoice</button>
                        <a href="<?php echo e(route('carts.index')); ?>" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </section>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/checkout/multiple.blade.php ENDPATH**/ ?>