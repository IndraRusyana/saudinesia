<div class="container d-flex my-3">
    <ol class="breadcrumb">
        <li class="breadcrumb-item active "><i class="fa-solid fa-house pe-2"></i><a href="#" class="pr-md-3 pl-md-2 pr-2 pl-1 ">Home</a></li>
        <li class="breadcrumb-item "><a href="#" class="px-md-3 px-1 my-3">Paket </a></li>
        <li class="breadcrumb-item "><a href="#" class="px-md-3 px-1"> Haji</a> </li>
    </ol>
</div><?php /**PATH D:\gawean\Saudenisia\app\resources\views/components/user/breadcumb.blade.php ENDPATH**/ ?>