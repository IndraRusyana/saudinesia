

<?php $__env->startSection('title'); ?>
    Dashboard Hotel | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="page-title my-3">
                        <h3 class="mb-0">Edit Hotel</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">Form Edit Hotel</div>
                                <div class="card-body">
                                    <h5 class="card-title mb-3">Silahkan isi form berikut untuk menambah paket hotel</h5>
                                    <form action="<?php echo e(route('admin.hotel.update', $hotel->id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>

                                        <div class="mb-3">
                                            <label>Nama Hotel</label>
                                            <input type="text" name="name" class="form-control"
                                                value="<?php echo e(old('name', $hotel->name)); ?>">
                                        </div>

                                        <div class="mb-3">
                                            <label for="city_id" class="form-label">Kota</label>
                                            <select name="city_id" id="city_id" class="form-select" required>
                                                <option value="">-- Pilih Kota --</option>
                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($city->id); ?>"
                                                        <?php echo e(old('city_id', $hotel->city_id ?? '') == $city->id ? 'selected' : ''); ?>>
                                                        <?php echo e($city->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label>Alamat</label>
                                            <textarea name="address" class="form-control"><?php echo e(old('address', $hotel->address)); ?></textarea>
                                        </div>

                                        <div class="mb-3">
                                            <label>Deskripsi</label>
                                            <textarea name="description" class="form-control"><?php echo e(old('description', $hotel->description)); ?></textarea>
                                        </div>

                                        <div class="mb-3">
                                            <label>Link Google Maps (opsional)</label>
                                            <input type="url" name="map_url" class="form-control"
                                                value="<?php echo e(old('map_url', $hotel->map_url)); ?>">
                                        </div>

                                        <div class="mb-3">
                                            <label>Gambar Hotel (maksimal 4)</label>
                                            <div class="row">
                                                <?php $__currentLoopData = range(1, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $image = $hotel->images->get($i - 1);
                                                    ?>
                                                    <div class="col-md-3 mb-3">
                                                        <label for="image<?php echo e($i); ?>">Gambar
                                                            <?php echo e($i); ?></label>
                                                        <input type="file" name="image<?php echo e($i); ?>"
                                                            class="form-control mb-1">
                                                        <?php if($image): ?>
                                                            <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>"
                                                                class="img-thumbnail" width="150">
                                                        <?php else: ?>
                                                            <img src="https://via.placeholder.com/150x100?text=No+Image"
                                                                class="img-thumbnail" width="150">
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>


                                        <h5>Harga per Periode & Tipe Kamar</h5>
                                        <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $hasPeriod =
                                                    $hotel->prices->where('period_id', $period->id)->count() > 0;
                                            ?>
                                            <div class="border p-3 mb-3 rounded">
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="checkbox"
                                                        value="<?php echo e($period->id); ?>" name="active_periods[]"
                                                        id="period_<?php echo e($period->id); ?>" <?php echo e($hasPeriod ? 'checked' : ''); ?>>
                                                    <label class="form-check-label" for="period_<?php echo e($period->id); ?>">
                                                        <strong><?php echo e($period->name); ?></strong>
                                                        (<?php echo e($period->formatted_start_date); ?> -
                                                        <?php echo e($period->formatted_end_date); ?>)
                                                    </label>
                                                </div>

                                                <div class="row">
                                                    <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $existingPrice = $hotel->prices
                                                                ->where('period_id', $period->id)
                                                                ->where('room_type_id', $roomType->id)
                                                                ->first();
                                                        ?>
                                                        <div class="col-md-4 mt-2">
                                                            <label><?php echo e($roomType->name); ?> - Harga</label>
                                                            <input type="number"
                                                                name="prices[<?php echo e($period->id); ?>][<?php echo e($roomType->id); ?>]"
                                                                class="form-control"
                                                                value="<?php echo e($existingPrice ? $existingPrice->price : ''); ?>">
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <button type="submit" class="btn btn-success">Update Hotel</button>
                                        <a href="<?php echo e(route('admin.hotel.index')); ?>" class="btn btn-secondary">Batal</a>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/hotel/edit.blade.php ENDPATH**/ ?>