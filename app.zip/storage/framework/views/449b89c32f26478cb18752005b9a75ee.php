

<?php $__env->startSection('title'); ?>
    Dashboard Merchandise | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Paket'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="page-title my-3 d-flex justify-content-between align-items-center pb-3">
                        <h3 class="mb-0">Merchandise</h3>
                        <a href="/admin/merchandise-tambah" class="btn btn-primary">Tambah Paket</a>
                    </div>
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-3">
                                <div class="card mb-3">
                                    <img class="card-img-top" src="<?php echo e(asset('uploads/' . $item->images)); ?>" alt="Card images cap">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                        <p class="card-text"><?php echo e(Str::limit($item->description, 100, '...')); ?></p>
                                        <p class="card-text"><small class="text-muted">Rp <?php echo e(number_format($item->prices, 0, ',', '.')); ?></small></p>
                                    </div>
                                    <div class="card-footer">
                                        <a class="btn btn-primary" href="<?php echo e(route('admin.merchandise.edit', $item->id)); ?>">Edit</a>
                                        <form action="<?php echo e(route('admin.merchandise.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"
                                                onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12 text-center">
                                <div class="alert alert-warning">Belum ada data Merchandise yang tersedia.</div>
                            </div>
                        <?php endif; ?>
                    
                        <?php if($query->hasPages()): ?>
                            <div class="my-5 d-flex justify-content-center">
                                <?php echo $query->withQueryString()->links('pagination::bootstrap-5'); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/merchandise/index.blade.php ENDPATH**/ ?>