

<?php $__env->startSection('title'); ?>
    Paket Umroh | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('umroh'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <section>
            <div class="container mt-5">
                <div class="row g-4">
                    <?php $__empty_1 = true; $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div id="" class="col-lg-3">
                            <a href="/umroh/detail/<?php echo e($item->id); ?>">
                                <div class="card mb-3">
                                    <img src="<?php echo e(asset('storage/' . $item->images)); ?>" alt="" class="card-img-top">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                        <p class="card-text text-dark"><?php echo e(Str::limit($item->description, 100, '...')); ?></p>
                                        <p class="card-text"><small class="text-muted">Rp
                                                <?php echo e(number_format($item->prices, 0, ',', '.')); ?></small></p> 
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center vh-100">
                            <div class="alert alert-warning">Belum ada data paket haji yang tersedia.</div>
                        </div>
                    <?php endif; ?>
                    <!-- Pagination Links -->
                    <div class="mt-4 d-flex justify-content-center">
                        <?php echo $query->withQueryString()->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
    </div>
    </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/paketUmroh.blade.php ENDPATH**/ ?>