

<?php $__env->startSection('title'); ?>
    Checkout | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <section>
            <div class="container contact-form-section py-5 ">
                <div class="form-section shadow-sm border">
                    <!-- Stepper -->
                    <div class="stepper mb-4">
                        <div class="step-circle">1</div>
                        <div class="step-circle inactive">2</div>
                        <div class="step-circle inactive">3</div>
                    </div>

                    <h3>Konfirmasi Pembelian</h3>

                    <p>Layanan: <?php echo e($itemable->name ?? $itemable->title); ?></p>
                    <p>Harga: Rp<?php echo e(number_format($unit_price, 0, ',', '.')); ?></p>
                    <p>Jumlah: <?php echo e($quantity); ?></p>
                    <p><strong>Total: Rp<?php echo e(number_format($total, 0, ',', '.')); ?></strong></p>

                    <form method="POST" action="<?php echo e(route('invoice.generate')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="itemable_type" value="<?php echo e(get_class($itemable)); ?>">
                        <input type="hidden" name="itemable_id" value="<?php echo e($itemable->id); ?>">
                        <input type="hidden" name="quantity" value="<?php echo e($quantity); ?>">
                        <input type="hidden" name="unit_price" value="<?php echo e($unit_price); ?>">
                        <button type="submit" class="btn btn-success">Lanjut ke Invoice</button>
                    </form>

                </div>

            </div>

        </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/checkout.blade.php ENDPATH**/ ?>