

<?php $__env->startSection('title'); ?>
    Invoice | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('invoice'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <section>
            <div class="container invoice-section py-5 ">
                <div class="form-section shadow-sm border">
                    <!-- Stepper -->
                    <div class="stepper mb-4">
                        <div class="step-circle">1</div>
                        <div class="step-circle active">2</div>
                        <div class="step-circle">3</div>
                    </div>

                    <h4>Upload Bukti Pembayaran</h4>
                    <p>Invoice: <strong><?php echo e($transaction->invoice_number); ?></strong></p>

                    <form action="<?php echo e(route('invoice.upload', $transaction->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="payment_proof" class="form-label">Upload Bukti (jpg/png)</label>
                            <input type="file" name="payment_proof" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Kirim Bukti Pembayaran</button>
                    </form>

                </div>

            </div>

        </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/invoice/upload.blade.php ENDPATH**/ ?>