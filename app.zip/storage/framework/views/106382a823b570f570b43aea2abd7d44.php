

<?php $__env->startSection('title'); ?>
    Dashboard Periode | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Periode'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <div class="page-title my-3">
                        <h3 class="mb-0">Edit Periode</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">Form Edit Periode</div>
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title mb-3">Silahkan isi form berikut untuk mengubah Periode</h5>
                                    <form action="<?php echo e(route('admin.periods.update', $periods->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                    
                                        
                                        <div class="mb-3 row">
                                            <label class="col-sm-2 col-form-label" for="name">Nama Periode</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="name" id="name" value="<?php echo e(old('name', $periods->name)); ?>" class="form-control" required>
                                            </div>
                                        </div>
                                    
                                        
                                        <div class="mb-3 row">
                                            <label class="col-sm-2 col-form-label" for="start_date">Tanggal Mulai</label>
                                            <div class="col-sm-10">
                                                <input type="date" name="start_date" id="start_date" value="<?php echo e(old('start_date', \Carbon\Carbon::parse($periods->start_date)->format('Y-m-d'))); ?>" class="form-control" required>
                                            </div>
                                        </div>
                                    
                                        
                                        <div class="mb-3 row">
                                            <label class="col-sm-2 col-form-label" for="end_date">Tanggal Selesai</label>
                                            <div class="col-sm-10">
                                                <input type="date" name="end_date" id="end_date" value="<?php echo e(old('end_date', \Carbon\Carbon::parse($periods->end_date)->format('Y-m-d'))); ?>" class="form-control" required>
                                            </div>
                                        </div>
                                    
                                        
                                        <div class="mb-3 row">
                                            <div class="col-sm-10 offset-sm-2">
                                                <button type="submit" class="btn btn-primary">Perbarui</button>
                                                <a href="<?php echo e(route('admin.periods.index')); ?>" class="btn btn-secondary">Batal</a>
                                            </div>
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/periods/edit.blade.php ENDPATH**/ ?>