

<?php $__env->startSection('title'); ?>
    Dashboard LA | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('LA'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="page-title my-3 d-flex justify-content-between align-items-center pb-3">
                        <h3 class="mb-0">Daftar Land Arrangements</h3>
                        <a href="<?php echo e(route('land-arrangements.create')); ?>" class="btn btn-primary">Tambah LA</a>
                    </div>

                    <div class="row px-2">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama LA</th>
                                    <th>Daftar Layanan</th>
                                    <th>Umroh</th>
                                    <th>Haji</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $landArrangements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $la): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($la->id); ?></td>
                                        <td><?php echo e($la->name); ?></td>
                                        <td>
                                            <ul class="mb-0 ps-3">
                                                <?php $__currentLoopData = $la->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <?php if($item->serviceable): ?>
                                                            <?php echo e(class_basename($item->serviceable_type)); ?>:
                                                            <?php echo e($item->serviceable->name); ?>

                                                        <?php elseif($item->custom_name): ?>
                                                            Kustom: <?php echo e($item->custom_name); ?>

                                                        <?php else: ?>
                                                            <em>Tanpa nama</em>
                                                        <?php endif; ?>
                                                        <?php if($item->keterangan): ?>
                                                            <br><small class="text-muted"><?php echo e($item->keterangan); ?></small>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </td>
                                        <td>
                                            <?php $__currentLoopData = $la->umrohs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <li><?php echo e($item->name); ?></li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <?php $__currentLoopData = $la->hajis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <li><?php echo e($item->name); ?></li> 
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('land-arrangements.edit', $la->id)); ?>"
                                                class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(route('land-arrangements.destroy', $la->id)); ?>" method="POST"
                                                class="d-inline" onsubmit="return confirm('Yakin ingin menghapus LA ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger btn-sm">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php if($landArrangements->hasPages()): ?>
                            <div class="my-4 d-flex justify-content-center">
                                <?php echo $landArrangements->withQueryString()->links('pagination::bootstrap-5'); ?>

                            </div>
                        <?php endif; ?>
                    </div>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/LA/index.blade.php ENDPATH**/ ?>