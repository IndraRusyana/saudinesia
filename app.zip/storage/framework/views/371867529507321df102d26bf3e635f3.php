

<?php $__env->startSection('title'); ?>
    Profile User | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Profil Saya</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Terjadi kesalahan:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('profiles.update')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" class="form-control" value="<?php echo e(old('nama_lengkap', $userProfile->nama_lengkap)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Tempat Lahir</label>
            <input type="text" name="tempat_lahir" class="form-control" value="<?php echo e(old('tempat_lahir', $userProfile->tempat_lahir)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo e(old('tanggal_lahir', $userProfile->tanggal_lahir)); ?>" required>
        </div>

        <div class="mb-3">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control">
                <option value="Laki-laki" <?php echo e(old('jenis_kelamin', $userProfile->jenis_kelamin) == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                <option value="Perempuan" <?php echo e(old('jenis_kelamin', $userProfile->jenis_kelamin) == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
            </select>
        </div>

        <div class="mb-3">
            <label>No HP</label>
            <input type="text" name="no_hp" class="form-control" value="<?php echo e(old('no_hp', $userProfile->no_hp)); ?>">
        </div>

        <div class="mb-3">
            <label>Pekerjaan</label>
            <input type="text" name="pekerjaan" class="form-control" value="<?php echo e(old('pekerjaan', $userProfile->pekerjaan)); ?>">
        </div>

        <div class="mb-3">
            <label>No Paspor</label>
            <input type="text" name="no_paspor" class="form-control" value="<?php echo e(old('no_paspor', $userProfile->no_paspor)); ?>">
        </div>

        <div class="mb-3">
            <label>Paspor Terbit</label>
            <input type="date" name="paspor_terbit" class="form-control" value="<?php echo e(old('paspor_terbit', $userProfile->paspor_terbit)); ?>">
        </div>

        <div class="mb-3">
            <label>Paspor Kadaluarsa</label>
            <input type="date" name="paspor_kadaluarsa" class="form-control" value="<?php echo e(old('paspor_kadaluarsa', $userProfile->paspor_kadaluarsa)); ?>">
        </div>

        <div class="mb-3">
            <label>Wilayah Terbit</label>
            <input type="text" name="wilayah_terbit" class="form-control" value="<?php echo e(old('wilayah_terbit', $userProfile->wilayah_terbit)); ?>">
        </div>

        <div class="mb-3">
            <label>Foto</label><br>
            <?php if($userProfile->photo): ?>
                <img src="<?php echo e(asset('storage/' . $userProfile->photo)); ?>" width="100" class="mb-2"><br>
            <?php endif; ?>
            <input type="file" name="photo" class="form-control">
        </div>

        <div class="mb-3">
            <label>Lampiran Paspor</label><br>
            <?php if($userProfile->lampiran_paspor): ?>
                <a href="<?php echo e(asset('storage/' . $userProfile->lampiran_paspor)); ?>" target="_blank">Lihat File</a><br>
            <?php endif; ?>
            <input type="file" name="lampiran_paspor" class="form-control">
        </div>

        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="<?php echo e(route('profiles.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/profiles/edit.blade.php ENDPATH**/ ?>