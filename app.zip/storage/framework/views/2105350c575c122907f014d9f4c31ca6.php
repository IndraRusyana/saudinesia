

<?php $__env->startSection('title'); ?>
    Detail Umroh | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('paket'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <section>
            <div class="container vh-100 py-5">
                <div class="row g-4">
                    <!-- Image Grid -->
                    <div class="col-lg-8">
                        <div class="row g-2 image-grid">
                            <div class="col-12">
                                <img src="<?php echo e(asset('storage/' . $umroh->images)); ?>" class="img-fluid w-100 img-large"
                                    alt="<?php echo e($umroh->name); ?>">
                            </div>
                            
                            
                        </div>
                    </div>

                    <!-- Info & Sidebar -->
                    <div class="col-lg-4">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h4 class="fw-bold"><?php echo e($umroh->name); ?></h4>
                                <p class="text-muted mb-2">Bus, 100 kapasitas</p> 
                            </div>
                            <div>
                                <i class="bi bi-heart me-2"></i>
                                <i class="bi bi-share"></i>
                            </div>
                        </div>

                        <div class="price-box mt-4">
                            <h5 class="fw-bold">IDR. <?php echo e(number_format($umroh->prices, 0, ',', '.')); ?></h5>
                            <hr>
                            <form action="<?php echo e(route('checkout.confirm')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="itemable_type" value="<?php echo e(get_class($item)); ?>">
                                <input type="hidden" name="itemable_id" value="<?php echo e($item->id); ?>">
                                <input type="hidden" name="quantity" value="1">
                                <input type="hidden" name="unit_price" value="<?php echo e($item->prices); ?>">
                                <button type="submit" class="btn btn-dark btn-dark-rounded mb-3">Pesan Langsung</button>
                            </form>
                            <?php echo $__env->make('components.success', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <form action="<?php echo e(route('carts.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="itemable_type" value="<?php echo e(get_class($item)); ?>">
                                <input type="hidden" name="itemable_id" value="<?php echo e($item->id); ?>">
                                <input type="hidden" name="unit_price" value="<?php echo e($item->prices); ?>">

                                <div class="mb-2">
                                    <label for="quantity">Jumlah:</label>
                                    <input type="number" name="quantity" value="1" min="1" class="form-control"
                                        required>
                                </div>

                                <div class="mb-2">
                                    <label for="description">Keterangan (opsional):</label>
                                    <input type="text" name="description" class="form-control"
                                        placeholder="Misalnya: ukuran, warna, dsb">
                                </div>

                                <button type="submit" class="btn btn-primary">Tambah ke Keranjang</button>

                            </form>
                            <div class="text-center">
                                <i class="bi bi-telephone"></i> <small>Contact Host</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Deskripsi -->
                <div class="row mt-5">
                    <div class="col-lg-8">
                        <h6 class="fw-bold">Deskripsi Paket</h6>
                        <p class="text-muted"><?php echo nl2br(e($umroh->description)); ?></p>
                    </div>
                </div>
            </div>

        </section>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/detailUmroh.blade.php ENDPATH**/ ?>