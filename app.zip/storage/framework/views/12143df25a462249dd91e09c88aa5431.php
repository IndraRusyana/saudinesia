

<?php $__env->startSection('title'); ?>
    Layanan Muttowif | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('muttowif'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <section class="d-flex justify-content-center align-items-center my-5">
            <div class="card p-4" style="max-width: 500px; width: 100%;">
                <h4 class="text-center mb-2">Pemesanan Muttowif</h4>
                <hr>
                <p class="text-center form-description mb-4">Isi form tersebut untuk memesan Muttowif</p>

                <form action="<?php echo e(route('user.muttowif.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3 mb-3">
                        <div class="col">
                            <label for="mulai" class="form-label">Mulai</label>
                            <input type="date" id="mulai" name="start_date" class="form-control" required>
                        </div>
                        <div class="col">
                            <label for="sampai" class="form-label">Sampai</label>
                            <input type="date" id="sampai" name="end_date" class="form-control" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="jumlah" class="form-label">Jumlah Jamaah</label>
                        <input type="number" id="jumlah" name="jamaah_count" class="form-control" min="1"
                            required>
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn btn-dark">Pesan</button>
                    </div>
                </form>

            </div>
        </section>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/serviceMuttowif.blade.php ENDPATH**/ ?>