

<?php $__env->startSection('title'); ?>
    Layanan Hotel | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <section id="section-1" class="my-5">
            <div class="container">
                <form method="GET" action="<?php echo e(route('user.hotel.index')); ?>">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="more-info shadow-sm border mx-auto">
                                <div class="row align-items-center">
                                    <div class="col-lg-4 col-sm-6 col-6">
                                        <i class="fa-solid fa-location-dot" style="cursor: pointer"></i>
                                        <h4>
                                            <span>Kota:</span><br>
                                            <select name="city">
                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($city->id); ?>"
                                                        <?php echo e($city->id == $cityId ? 'selected' : ''); ?>>
                                                        <?php echo e($city->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </h4>
                                    </div>
                                    <div class="col-lg-4 col-sm-6 col-6">
                                        <i class="fa-solid fa-calendar-days" style="cursor: pointer"></i>
                                        <h4>
                                            <span>Periode:</span><br>
                                            <select name="period">
                                                <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($period->id); ?>"
                                                        <?php echo e($period->id == $periodId ? 'selected' : ''); ?>>
                                                        <?php echo e($period->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </h4>
                                    </div>
                                    <div class="col-lg-3 col-sm-6 col-6 mt-4">
                                        <div class="main-button">
                                            <button type="submit" class="btn btn-primary">Cari</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>


        <div class="container pt-4">
            <h5 class="">
                Menampilkan Hotel
                <?php if($cityId): ?>
                    di <?php echo e($cities->firstWhere('id', $cityId)->name); ?>

                <?php endif; ?>
                <?php if($periodId): ?>
                    pada periode <?php echo e($periods->firstWhere('id', $periodId)->name); ?>

                <?php endif; ?>
            </h5>
        </div>


        <section>
            <div class="container mt-5">
                <div class="row gx-4">
                    <?php $__empty_1 = true; $__currentLoopData = $hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-3 mb-4">
                            <a href="<?php echo e(route('user.hotel.detail', [
                                'id' => $item->id,
                                'period_id' => $periodId,
                                'city_id' => $cityId,
                            ])); ?>"
                                style="text-decoration: none; color: inherit;">
                                <div class="card h-100">
                                    
                                    <?php if($item->images->first()): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->images->first()->image_path)); ?>"
                                            alt="Hotel Image" class="card-img-top">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/no-image.jpg')); ?>" alt="No Image" class="card-img-top">
                                    <?php endif; ?>

                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                        <p class="card-text text-dark">
                                            <?php echo e(Str::limit($item->description, 100, '...')); ?> <br>
                                            <small class="text-muted">
                                                <?php echo str_repeat('★', $item->stars); ?><?php echo str_repeat('☆', 5 - $item->stars); ?>

                                            </small>
                                        </p>
                                        <p class="card-text">
                                            <small
                                                class="text-muted"><?php echo e($item->city?->name ?? 'Kota tidak tersedia'); ?></small>
                                        </p>

                                        
                                        <?php
                                            $price = optional($item->prices->first())->price;
                                        ?>

                                        <?php if($price): ?>
                                            <p class="card-text"><small class="text-muted">Rp
                                                    <?php echo e(number_format($price, 0, ',', '.')); ?></small></p>
                                        <?php else: ?>
                                            <p class="card-text"><small class="text-muted">Harga belum tersedia</small></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">
                            <div class="alert alert-warning">Belum ada data hotel yang tersedia.</div>
                        </div>
                    <?php endif; ?>

                    <!-- Pagination Links -->
                    <div class="col-12 mt-4">
                        <?php echo $hotel->withQueryString()->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </section>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/serviceHotel.blade.php ENDPATH**/ ?>