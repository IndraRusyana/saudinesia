

<?php $__env->startSection('title'); ?>
    Layanan Visa | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('visa'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!-- breadcumb -->
        <?php if (isset($component)) { $__componentOriginal8b80ed6acba69eca5317068c1f58af26 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b80ed6acba69eca5317068c1f58af26 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.breadcrumb','data' => ['breadcrumbs' => $breadcrumbs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($breadcrumbs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $attributes = $__attributesOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__attributesOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b80ed6acba69eca5317068c1f58af26)): ?>
<?php $component = $__componentOriginal8b80ed6acba69eca5317068c1f58af26; ?>
<?php unset($__componentOriginal8b80ed6acba69eca5317068c1f58af26); ?>
<?php endif; ?>
        <!-- breadcumb -->

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <section class="d-flex justify-content-center my-5">
            <div class="card p-4" style="max-width: 900px; width: 100%;">
                <h4 class="text-center mb-2">Pengajuan Visa</h4>
                <hr>
                <p class="text-center text-muted">Isi form tersebut untuk pengajuan visa</p>

                <form action="<?php echo e(route('user.visa.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-3">
                        <label for="is_self" class="form-label">Ajukan untuk:</label>
                        <select name="is_self" id="is_self" class="form-select" onchange="toggleManualForm()">
                            <option value="1" <?php echo e(old('is_self') == '1' ? 'selected' : ''); ?>>Diri sendiri</option>
                            <option value="0" <?php echo e(old('is_self') == '0' ? 'selected' : ''); ?>>Orang lain</option>
                        </select>
                    </div>

                    
                    <div id="manual-form" style="display: none;">
                        <h5>Data Pemohon</h5>
                        <?php $__currentLoopData = [
            'nama_lengkap' => 'Nama Lengkap',
            'tempat_lahir' => 'Tempat Lahir',
            'tanggal_lahir' => 'Tanggal Lahir',
            'jenis_kelamin' => 'Jenis Kelamin',
            'pekerjaan' => 'Pekerjaan',
            'no_hp' => 'No HP',
            'no_paspor' => 'No Paspor',
            'paspor_terbit' => 'Tanggal Terbit Paspor',
            'paspor_kadaluarsa' => 'Tanggal Kadaluarsa Paspor',
            'wilayah_terbit' => 'Wilayah Terbit Paspor',
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
                                <input type="<?php echo e(str_contains($field, 'tanggal') ? 'date' : 'text'); ?>"
                                    name="<?php echo e($field); ?>" class="form-control" value="<?php echo e(old($field)); ?>">
                                <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <div class="mb-3">
                            <label class="form-label">Jenis Kelamin</label><br>
                            <label><input type="radio" name="jenis_kelamin" value="Laki-laki"
                                    <?php echo e(old('jenis_kelamin') == 'Laki-laki' ? 'checked' : ''); ?>> Laki-laki</label>
                            <label><input type="radio" name="jenis_kelamin" value="Perempuan"
                                    <?php echo e(old('jenis_kelamin') == 'Perempuan' ? 'checked' : ''); ?>> Perempuan</label>
                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <h5>Detail Keberangkatan</h5>
                    <?php $__currentLoopData = [
            'tanggal_berangkat' => 'Tanggal Berangkat',
            'maskapai_berangkat' => 'Maskapai Berangkat',
            'no_penerbangan_berangkat' => 'Nomor Penerbangan Berangkat',
            'tanggal_kembali' => 'Tanggal Kembali',
            'maskapai_kembali' => 'Maskapai Kembali',
            'no_penerbangan_kembali' => 'Nomor Penerbangan Kembali',
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3">
                            <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
                            <input type="<?php echo e(str_contains($field, 'tanggal') ? 'date' : 'text'); ?>"
                                name="<?php echo e($field); ?>" class="form-control" value="<?php echo e(old($field)); ?>">
                            <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <h5>Detail Hotel</h5>
                    <?php $__currentLoopData = [
            'hotel_mekkah' => 'Hotel Mekkah',
            'checkin_mekkah' => 'Check-In Mekkah',
            'checkout_mekkah' => 'Check-Out Mekkah',
            'hotel_madinah' => 'Hotel Madinah',
            'checkin_madinah' => 'Check-In Madinah',
            'checkout_madinah' => 'Check-Out Madinah',
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3">
                            <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
                            <input type="<?php echo e(str_contains($field, 'check') ? 'date' : 'text'); ?>" name="<?php echo e($field); ?>"
                                class="form-control" value="<?php echo e(old($field)); ?>">
                            <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <h5>Lampiran</h5>
                    <?php $__currentLoopData = [
            'lampiran_ktp' => 'KTP',
            'lampiran_kk' => 'Kartu Keluarga',
            'lampiran_paspor' => 'Paspor',
            'lampiran_tiket' => 'lampiran/tiket.jpg',
            'lampiran_hotel' => 'lampiran/hotel.jpg',
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isPaspor = $field === 'lampiran_paspor';
                        ?>
                        <div class="mb-3 <?php echo e($isPaspor ? '' : ''); ?>" id="<?php echo e($isPaspor ? 'lampiran-paspor-wrapper' : ''); ?>">
                            <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
                            <input type="file" name="<?php echo e($field); ?>" class="form-control">
                            <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <button type="submit" class="btn btn-primary">Ajukan Visa</button>
                </form>

            </div>
        </section>


    </div>
    <script>
        function toggleManualForm() {
            const isSelf = document.getElementById('is_self').value === '1';
            document.getElementById('manual-form').style.display = isSelf ? 'none' : 'block';
            document.getElementById('lampiran-paspor-wrapper').style.display = isSelf ? 'none' : 'block';
        }

        // Jalankan saat halaman pertama kali dimuat
        document.addEventListener('DOMContentLoaded', toggleManualForm);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/serviceVisa.blade.php ENDPATH**/ ?>