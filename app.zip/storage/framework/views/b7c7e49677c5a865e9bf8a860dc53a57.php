<div class="container d-flex my-3">
    <ol class="breadcrumb">
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loop->last || $breadcrumb['url'] === null): ?>
                <li class="breadcrumb-item ">
                    <?php if($loop->first): ?>
                        <i class="fa-solid fa-house pe-2"></i>
                    <?php endif; ?>
                    <?php echo e($breadcrumb['label']); ?>

                </li>
            <?php else: ?>
                <li class="breadcrumb-item">
                    <?php if($loop->first): ?>
                        <i class="fa-solid fa-house pe-2"></i>
                    <?php endif; ?>
                    <a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['label']); ?></a>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</div>
<?php /**PATH D:\gawean\Saudenisia\app\resources\views/components/user/breadcrumb.blade.php ENDPATH**/ ?>