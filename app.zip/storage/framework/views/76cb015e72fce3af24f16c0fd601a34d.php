<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

                    <?php /**PATH D:\gawean\Saudenisia\app\resources\views/components/success.blade.php ENDPATH**/ ?>