

<?php $__env->startSection('title'); ?>
    Profile User | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('profile'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Profil Saya</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($profile): ?>
        <table class="table table-bordered">
            <tr>
                <th>Nama Lengkap</th>
                <td><?php echo e($profile->nama_lengkap); ?></td>
            </tr>
            <tr>
                <th>Tempat, Tanggal Lahir</th>
                <td><?php echo e($profile->tempat_lahir); ?>, <?php echo e($profile->tanggal_lahir); ?></td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td><?php echo e($profile->jenis_kelamin); ?></td>
            </tr>
            <tr>
                <th>No HP</th>
                <td><?php echo e($profile->no_hp); ?></td>
            </tr>
            <tr>
                <th>Pekerjaan</th>
                <td><?php echo e($profile->pekerjaan); ?></td>
            </tr>
            <tr>
                <th>Paspor</th>
                <td><?php echo e($profile->no_paspor ?? '-'); ?></td>
            </tr>
            <tr>
                <th>Lampiran Paspor</th>
                <td>
                    <?php if($profile->lampiran_paspor): ?>
                        <a href="<?php echo e(asset('storage/' . $profile->lampiran_paspor)); ?>" target="_blank">Lihat</a>
                    <?php else: ?>
                        Tidak ada
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Foto</th>
                <td>
                    <?php if($profile->photo): ?>
                        <img src="<?php echo e(asset('storage/' . $profile->photo)); ?>" width="100">
                    <?php else: ?>
                        Tidak ada
                    <?php endif; ?>
                </td>
            </tr>
        </table>

        <a href="<?php echo e(route('profiles.edit', $profile->id)); ?>" class="btn btn-warning">Edit Profil</a>
    <?php else: ?>
        <p>Profil belum tersedia.</p>
        <a href="<?php echo e(route('profiles.create')); ?>" class="btn btn-primary">Buat Profil</a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/user/profiles/index.blade.php ENDPATH**/ ?>