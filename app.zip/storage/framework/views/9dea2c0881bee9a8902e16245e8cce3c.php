

<?php $__env->startSection('title'); ?>
    Dashboard Visa | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Visa'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="page-title my-3 d-flex justify-content-between align-items-center pb-3">
                        <h3 class="mb-0">Pemesanan Visa</h3>
                    </div>
                    <div class="row px-2">
                        <table class="table table-bordered table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lengkap</th>
                                    <th>Tempat, Tanggal Lahir</th>
                                    <th>Jenis Kelamin</th>
                                    <th>No Paspor</th>
                                    <th>Tanggal Berangkat</th>
                                    <th>Tanggal Kembali</th>
                                    <th>Akun</th>
                                    <th>Lampiran KTP</th>
                                    <th>Lampiran Paspor</th>
                                    <th>Lampiran KK</th>
                                    <th>Lampiran Tiket</th>
                                    <th>Lampiran Hotel</th>
                                    <th>Tanggal Pengajuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $visa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($item->nama_lengkap); ?></td>
                                        <td><?php echo e($item->tempat_lahir); ?>,
                                            <?php echo e(\Carbon\Carbon::parse($item->tanggal_lahir)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($item->jenis_kelamin); ?></td>
                                        <td><?php echo e($item->no_paspor ?? '-'); ?></td>
                                        <td><?php echo e(optional($item->tanggal_berangkat)->format('d-m-Y')); ?></td>
                                        <td><?php echo e(optional($item->tanggal_kembali)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($item->user->name ?? '-'); ?></td>

                                        
                                        <td>
                                            <?php if($item->lampiran_ktp): ?>
                                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(asset('uploads/' . $item->lampiran_ktp)); ?>"
                                                    target="_blank">Lihat</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->lampiran_paspor): ?>
                                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(asset('uploads/' . $item->lampiran_paspor)); ?>"
                                                    target="_blank">Lihat</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->lampiran_kk): ?>
                                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(asset('uploads/' . $item->lampiran_kk)); ?>"
                                                    target="_blank">Lihat</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->lampiran_tiket): ?>
                                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(asset('uploads/' . $item->lampiran_tiket)); ?>"
                                                    target="_blank">Lihat</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->lampiran_hotel): ?>
                                                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(asset('uploads/' . $item->lampiran_hotel)); ?>"
                                                    target="_blank">Lihat</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>

                                        <td><?php echo e($item->created_at->format('d-m-Y H:i')); ?></td>
                                        <td>
                                            <a href="#" class="btn btn-success btn-sm">Konfirmasi</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="15" class="text-center">Belum ada data pengajuan visa.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <?php if($visa->hasPages()): ?>
                            <div class="my-4 d-flex justify-content-center">
                                <?php echo $visa->withQueryString()->links('pagination::bootstrap-5'); ?>

                            </div>
                        <?php endif; ?>



                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/visa/index.blade.php ENDPATH**/ ?>