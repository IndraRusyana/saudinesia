<div class="site-mobile-menu site-navbar-target">
    <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close">
            <span class="icofont-close js-menu-toggle"></span>
        </div>
    </div>
    <div class="site-mobile-menu-body"></div>
</div>

<?php if($home == 'home'): ?>
    <nav class="site-nav mt-3">
    <?php else: ?>
        <nav class="site-nav" style="position: relative; background-color:#D9D9D9;">
<?php endif; ?>
<div class="container">

    <div class="site-navigation">
        <div class="row">
            <div class="col-6 col-lg-3">
                <a href="index.html" class="logo m-0 float-start"><img
                        src="<?php echo e(asset('assets/user/images/LOGO_SAUDINESIA.png')); ?>" alt="" srcset=""
                        width="120"></a>
            </div>
            <div class="col-lg-6 d-none d-lg-inline-block text-center nav-center-wrap">
                <ul class="js-clone-nav  text-center site-menu p-0 m-0">
                    <li class=""><a href="/" class="<?php echo e($home == 'home' ? 'active-2' : ''); ?>"
                            style="font-weight: 600">Home</a></li>
                    <li class="has-children">
                        <a href="#" class="<?php echo e($home == 'haji' || $home == 'umroh' ? 'active-2' : ''); ?>"
                            style="font-weight: 600;">Paket</a>
                        <ul class="dropdown">
                            <li class="<?php echo e(request()->is('haji') ? 'active-2' : ''); ?>"><a href="/haji">Haji</a></li>
                            <li class="<?php echo e(request()->is('umroh') ? 'active-2' : ''); ?>"><a href="/umroh">Umroh</a></li>
                        </ul>
                    </li>
                    <li class="has-children">
                        <a href="#"
                            class="<?php echo e($home == 'hotel' || $home == 'transport' || $home == 'muttowif' || $home == 'visa' || $home == 'merchandise' ? 'active-2' : ''); ?>"
                            style="font-weight: 600">Layanan</a>
                        <ul class="dropdown">
                            <li class="<?php echo e(request()->is('hotel') ? 'active-2' : ''); ?>"><a href="/hotel">Hotel</a></li>
                            <li class="<?php echo e(request()->is('transport') ? 'active-2' : ''); ?>"><a
                                    href="/transport">Transport</a></li>
                            <li class="<?php echo e(request()->is('muttowif') ? 'active-2' : ''); ?>"><a
                                    href="/muttowif">Muttowif</a></li>
                            <li class="<?php echo e(request()->is('visa') ? 'active-2' : ''); ?>"><a href="/visa">Visa</a></li>
                            <li class="<?php echo e(request()->is('merchandise') ? 'active-2' : ''); ?>"><a
                                    href="/merchandise">Merchandise</a></li>
                        </ul>
                    </li>
                    <li><a href="/informasi" class="<?php echo e($home == 'informasi' ? 'active-2' : ''); ?>"
                            style="font-weight: 600">Informasi</a></li>
                    <li><a href="" class="<?php echo e($home == 'tentang kami' ? 'active-2' : ''); ?>"
                            style="font-weight: 600">Tentang Kami</a></li>
                    <li><a href="" class="<?php echo e($home == 'helpdesk' ? 'active-2' : ''); ?>"
                            style="font-weight: 600">Helpdesk</a></li>
                </ul>
            </div>
            <div class="col-6 col-lg-3 text-lg-end">
                <?php if(auth()->guard('user')->guest()): ?>
                    
                    <div class="button js-clone-nav d-none d-lg-inline-block px-0">
                        <a class="btn btn-light <?php echo e($home !== 'home' ? 'btn-dark' : ''); ?> px-3 py-2"
                            href="/login">Login</a>
                    </div>
                    <div class="button js-clone-nav d-none d-lg-inline-block">
                        <a class="btn btn-light <?php echo e($home !== 'home' ? 'btn-dark' : ''); ?> px-3 py-2"
                            href="/register">Register</a>
                    </div>
                <?php endif; ?>

                <?php if(auth()->guard('user')->check()): ?>
                    
                    <div class="dropdown d-none d-lg-inline-block">
                        <a class="btn btn-light dropdown-toggle <?php echo e($home !== 'home' ? 'btn-dark' : ''); ?> px-3 py-2"
                            href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                           <?php echo e(Auth::guard('user')->user()->profile->nama_lengkap); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li>
                                <a class="dropdown-item <?php echo e($home == 'profile' ? 'active-2' : ''); ?>"
                                    href="/profiles">Profile</a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php echo e($home == 'cart' ? 'active-2' : ''); ?>"
                                    href="/carts">Keranjang</a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php echo e($home == 'pesanan' ? 'active-2' : ''); ?>"
                                    href="/pesanan">Pesanan Saya</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <form method="POST" action="<?php echo e(route('user.logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item text-danger">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>


                <a href="#"
                    class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light"
                    data-toggle="collapse" data-target="#main-navbar">
                    <span></span>
                </a>
            </div>
        </div>
    </div>

</div>
</nav>
<?php /**PATH D:\gawean\Saudenisia\app\resources\views/components/user/navbar.blade.php ENDPATH**/ ?>