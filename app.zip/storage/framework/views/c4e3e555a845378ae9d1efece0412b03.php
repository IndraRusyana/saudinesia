

<?php $__env->startSection('title'); ?>
    Dashboard Hotel | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('layanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="page-title my-3">
                        <h3 class="mb-0">Tambah Hotel</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">Form Tambah Paket Hotel</div>
                                <div class="card-body">
                                    <h5 class="card-title mb-3">Silahkan isi form berikut untuk menambah paket hotel</h5>
                                    <form action="<?php echo e(route('admin.hotel.store')); ?>" method="POST"
                                        enctype="multipart/form-data" accept-charset="utf-8">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3 row">
                                            <label class="col-sm-2 form-label" for="name">Nama Hotel</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="name" class="form-control" required>
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label class="col-sm-2 form-label" for="address">Alamat</label>
                                            <div class="col-sm-10">
                                                <input type="text" name="address" class="form-control" required>
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label class="col-sm-2 form-label" for="descriotion">Deskripsi</label>
                                            <div class="col-sm-10">
                                                <textarea name="description" class="form-control" rows="4" required></textarea>
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label class="col-sm-2 form-label" for="map_url">Link Google Maps</label>
                                            <div class="col-sm-10">
                                                <input type="url" name="map_url" class="form-control">
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label class="col-sm-2 form-label" for="images">Gambar Hotel (boleh lebih dari
                                                satu)</label>
                                            <div class="col-sm-10">
                                                <input type="file" name="images[]" class="form-control" multiple
                                                    required>
                                            </div>
                                        </div>
                                        <hr>
                                        <h5>Harga per Periode & Tipe Kamar</h5>
                                        <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="border p-3 mb-3 rounded">
                                                <strong><?php echo e($period->name); ?> (<?php echo e($period->start_date); ?> -
                                                    <?php echo e($period->end_date); ?>)</strong>
                                                <div class="row">
                                                    <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-4 mt-2">
                                                            <label><?php echo e($roomType->name); ?> - Harga</label>
                                                            <input type="number"
                                                                name="prices[<?php echo e($period->id); ?>][<?php echo e($roomType->id); ?>]"
                                                                class="form-control" required>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mb-3 row">
                                            <div class="col-sm-10 offset-sm-2">
                                                <button type="submit" class="btn btn-primary">Tambah</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/hotel_tambah.blade.php ENDPATH**/ ?>