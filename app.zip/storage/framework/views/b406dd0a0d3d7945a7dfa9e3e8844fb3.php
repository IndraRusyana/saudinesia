

<?php $__env->startSection('title'); ?>
    Dashboard Hotel | Saudinesia
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Layanan'); ?>
    active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <!-- Sodebar -->
        <?php echo $__env->make('components.admin.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sodebar -->
        <div id="body">
            <!-- Navbar -->
            <?php echo $__env->make('components.admin.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!-- Navbar -->
            <div class="content">
                <div class="container">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="page-title my-3 d-flex justify-content-between align-items-center pb-3">
                        <h3 class="mb-0">Layanan Hotel</h3>
                        <a href="/admin/layanan/hotel-tambah" class="btn btn-primary">Tambah Hotel </a>
                    </div>
                    <div class="row">
                        <form method="GET" class="mb-3">
                            <div class="row g-2 align-items-center">
                                <div class="col-auto">
                                    <label for="period_id" class="col-form-label">Filter Periode:</label>
                                </div>
                                <div class="col-auto">
                                    <select name="period_id" id="period_id" class="form-select"
                                        onchange="this.form.submit()">
                                        <option value="">-- Semua Periode --</option>
                                        <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($period->id); ?>"
                                                <?php echo e(request('period_id') == $period->id ? 'selected' : ''); ?>>
                                                <?php echo e($period->name); ?> (<?php echo e($period->formatted_start_date); ?> -
                                                <?php echo e($period->formatted_end_date); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </form>

                        <div class="table-responsive">
                            <div style="min-width: 1200px">
                                <table class="table table-bordered table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th>#</th>
                                            <th>Nama</th>
                                            <th>Kota</th> 
                                            <th>Deskripsi</th>
                                            <th>Alamat</th>
                                            <th>Gambar</th>
                                            <th>Harga per Periode & Tipe Kamar</th>
                                            <th>Maps</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->city->name ?? '-'); ?></td> 
                                                <td><?php echo e(Str::limit($item->description, 100)); ?></td>
                                                <td><?php echo e($item->address); ?></td>
                                                <td>
                                                    <?php if($item->images->count() > 0): ?>
                                                        <!-- Tombol untuk membuka modal -->
                                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#imagesModal<?php echo e($item->id); ?>">
                                                            Lihat Gambar (<?php echo e($item->images->count()); ?>)
                                                        </button>

                                                        <!-- Modal -->
                                                        <div class="modal fade" id="imagesModal<?php echo e($item->id); ?>"
                                                            tabindex="-1"
                                                            aria-labelledby="imagesModalLabel<?php echo e($item->id); ?>"
                                                            aria-hidden="true">
                                                            <div class="modal-dialog modal-lg modal-dialog-centered">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title"
                                                                            id="imagesModalLabel<?php echo e($item->id); ?>">Gambar
                                                                            Hotel - <?php echo e($item->name); ?></h5>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Tutup"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="row">
                                                                            <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <div class="col-md-4 mb-3">
                                                                                    <img src="<?php echo e(asset('uploads/' . $image->image_path)); ?>"
                                                                                        class="img-fluid rounded shadow-sm">
                                                                                </div>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Tutup</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <span class="text-muted">Tidak ada gambar</span>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <?php if($item->prices->count()): ?>
                                                        <?php
                                                            $grouped = $item->prices->groupBy('period.name');
                                                        ?>

                                                        <?php $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodName => $prices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <strong><?php echo e($periodName); ?></strong><br>
                                                            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                - <?php echo e($price->roomType->name); ?>, Harga Rp.
                                                                <?php echo e(number_format($price->price, 0, ',', '.')); ?><br>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <span class="text-muted">Belum ada data harga.</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($item->map_url): ?>
                                                        <a href="<?php echo e($item->map_url); ?>" class="btn btn-sm btn-outline-info"
                                                            target="_blank">Lihat Maps</a>
                                                    <?php else: ?>
                                                        <span class="text-muted">Tidak tersedia</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a class="btn btn-sm btn-primary mb-1"
                                                        href="<?php echo e(route('admin.hotel.edit', $item->id)); ?>">Edit</a>
                                                    <form action="<?php echo e(route('admin.hotel.destroy', $item->id)); ?>"
                                                        method="POST" style="display:inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger"
                                                            onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="9" class="text-center text-muted">Belum ada data hotel yang
                                                    tersedia.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>

                        <?php if($hotels->hasPages()): ?>
                            <div class="my-4 d-flex justify-content-center">
                                <?php echo $hotels->withQueryString()->links('pagination::bootstrap-5'); ?>

                            </div>
                        <?php endif; ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\gawean\Saudenisia\app\resources\views/admin/hotel/index.blade.php ENDPATH**/ ?>