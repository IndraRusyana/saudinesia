<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TransportRoutes extends Model
{
    //
    protected $fillable = ['routes'];
    
}
