<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminHajiController extends Controller
{
    public function index()
    {
        return view('admin.haji');
    }
}
